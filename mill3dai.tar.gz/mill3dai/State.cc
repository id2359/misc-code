#include <iostream>
#include <cstdlib>
#include <GL/gl.h>
#include "Mill.h"

State *State::setMove(FieldPos *pos) {
  State *state;
  int a;
  int len;
  switch(action) {
  case MOVE_SET:
    len=abs(this->pos->a1 - pos->a1)+
        abs(this->pos->b1 - pos->b1)+
        abs(this->pos->c1 - pos->c1)+
        abs(this->pos->d1 - pos->d1);
    if((len>1) || (len==0))
      return 0;
  case SET:
  case JUMP_SET:
    if(pos->status != 0) {
      return 0;
    }
    this->pos=pos;
    pos->status=color;
    hasMill=0;
    for(a=0;a<4;a++) {
      if( pos->mill[a][0]->status == pos->mill[a][1]->status &&
        pos->mill[a][0]->status == pos->mill[a][2]->status &&
        pos->mill[a][0]->status == color) {
        hasMill=1;
        //	cout << "mill" << endl;
      }
    } 
    break;
  case REMOVE:
    {
      bool onlyMills = true;
      FieldPos* list[60];
      int count = field->getValidPositions(list);
      bool hasAnyStones = false;
      for(int i=0; i<count; i++) {
        if(list[i]->status == color) {
          hasAnyStones = true;
          bool inMill = false;
          for(int m=0; m<4; m++) {
            if( list[i]->mill[m][0]->status == color &&
                list[i]->mill[m][1]->status == color &&
                list[i]->mill[m][2]->status == color) {
              inMill = true;
              break;
            }
          }
          if(!inMill) {
            onlyMills = false;
            break;
          }
        }
      }
      if (!onlyMills || !hasAnyStones) {
        for(a=0;a<4;a++) {
          if( pos->mill[a][0]->status == pos->mill[a][1]->status &&
            pos->mill[a][0]->status == pos->mill[a][2]->status &&
            pos->mill[a][0]->status == color) {
            //	cout << "Kann nicht aus der mill nehmen" << endl;
            return 0;
          }
        }
      }
    }
    if(pos->status != color) {
      //      cout << "Darf nicht die eigene Farbe wegnehmen " << endl;
      return 0;
    }
  case MOVE_REMOVE:
  case JUMP_REMOVE:
    if(pos->status != color) {
      //      cout << "Darf keine fremden Steine bewegen" << endl;
      return 0;
    }
    this->pos=pos;
    break;
  default:
    return 0;
  }
  doMove();
  state=new State();
  *state=*this;
  state->nextMove();
  return state;
}

void State::doMove() {
  switch(action) {
  case SET:
    stones[color].toSet--;
  case MOVE_SET:
  case JUMP_SET:
    pos->status=color;
    break;
  case REMOVE:
    stones[color].left--;
  case MOVE_REMOVE:
  case JUMP_REMOVE:
    pos->status=0;
    break;
  }
}  

void State::nextMove() {
  int newColor;

  

  if(color==1) {
    newColor=2;
  } else {
    newColor=1;
  }
  if(hasMill) {
    hasMill=0;
    action=REMOVE;
    color=newColor;
    return;
  }
  
  switch(action) {
  case SET:
  case MOVE_SET:
  case JUMP_SET:
    color=newColor;
    break;
  }
  switch(action) {
  case SET:
  case REMOVE:
    if(stones[color].toSet==0) {
      if(stones[color].left==3) {
        action=JUMP_REMOVE;
      } else {
        action=MOVE_REMOVE;
      }
    } else {
      action=SET;
    }
    break;
  case MOVE_SET:
  case JUMP_SET:
    if(stones[color].left==3) {
      action=JUMP_REMOVE;
    } else {
      action=MOVE_REMOVE;
    }
    break;
  case MOVE_REMOVE:
    action=MOVE_SET;
    break;
  case JUMP_REMOVE:
    action=JUMP_SET;
    break;
  }
}

void State::undoMove() {
  switch(action) {
  case SET:
    stones[color].toSet++;
  case MOVE_SET:
  case JUMP_SET:
    pos->status=0;
    break;
  case REMOVE:
    stones[color].toSet--;
  case MOVE_REMOVE:
  case JUMP_REMOVE:
    pos->status=color;
    break;
  }
}

void State::redoMove() {
  switch(action) {
  case SET:
    stones[color].toSet--;
  case MOVE_SET:
  case JUMP_SET:
    pos->status=color;
    break;
  case REMOVE:
    stones[color].toSet++;
  case MOVE_REMOVE:
  case JUMP_REMOVE:
    pos->status=0;
    break;
  }
}
