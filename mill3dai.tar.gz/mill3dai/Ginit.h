#ifndef GINIT_H
#define GINIT_H

enum GlutKeys {
GLUT_KEY_UP,
GLUT_KEY_DOWN,
GLUT_KEY_LEFT,
GLUT_KEY_RIGHT,
GLUT_RIGHT_BUTTON,
GLUT_LEFT_BUTTON,
GLUT_DOWN,
GLUT_UP
};


class GInit {
public :
  GInit(int argc,char **argv,int width=640,int height=480);
  virtual void draw() {}
  virtual void init() {}
  virtual void idle() {}
  virtual void input( unsigned char k, int x, int y ) {}
  virtual void specialInput( int k,int x,int y) {}
  virtual int mouseFunc(int button,int state,int x,int y) {return 0;}
  virtual void passiveMotionFunc(int x,int y) {}
  virtual void motionFunc(int x,int y) {}
  void start();
  GLuint loadTexture(char *name);
  int getWidth() {return width;}
  int getHeight() {return height;}
public :
  static void drawCB();
  static void initCB();
  static void keyInputCB( unsigned char k,int x,int y);
  static void specialInputCB( int k,int x,int y);
  static void reshapeCB(int width_,int height_);
  static void mouseFuncCB(int button,int state,int x,int y);
  static void passiveMotionFuncCB(int x,int y);
  static void motionFuncCB(int x,int y);
  static void idleCB();
private :
  static GInit *instance;
  static int width;
  static int height;
  static int fullscreen;
};

#endif
