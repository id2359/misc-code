#ifndef STATE_H
#define STATE_H

#include "Field.h"

const int SET=1;
const int REMOVE=2;
const int MOVE_REMOVE=3;
const int MOVE_SET=4;
const int JUMP_REMOVE=5;
const int JUMP_SET=6;
const int MAX_STONES=18;
//const int MAX_STONES=3;

class State {
public:
  int color;
  int action;
  int hasMill;
  struct {
    int toSet;
    int left;
  } stones[3];
  FieldPos *pos;
  Field *field;

  State(){};
  State(Field *field) {
    this->field=field;
    stones[1].toSet=MAX_STONES;
    stones[1].left=stones[1].toSet;
    stones[2].toSet=stones[1].toSet;
    stones[2].left=stones[1].left;
    color=1;
    action=SET;
    hasMill=0;
  }

  State *setMove(FieldPos *pos);
  void undoMove();
  void redoMove();
  void nextMove();
  void doMove();
};


#endif

