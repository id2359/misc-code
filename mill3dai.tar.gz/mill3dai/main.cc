#include <QApplication>
#include "MillWindow.h"

int main( int argc, char ** argv ) {
    QApplication a( argc, argv );
    MillWindow * mw = new MillWindow();
    mw->show();
    return a.exec();
}

