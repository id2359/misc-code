Summary: an opengl implementation of 3D merrills 
Name: mill3d
Version: 1.1
Release: 1
Copyright: GPL
Group: X11/games
Source: mill3d-1.1.tgz
%description
An opengl implementation of 3D merrills. Mill3d is a game vor two players.
%prep
%setup
%build
make RPM_OPT_FLAGS="$RPM_OPT_FLAGS"
%install
install -s -m 755 -o 0 -g 0 mill3d /usr/bin/mill3d
%files
/usr/bin/mill3d
