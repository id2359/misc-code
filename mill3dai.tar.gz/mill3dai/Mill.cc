#define _USE_MATH_DEFINES
#include <cstdio>
#include <cmath>
#include <iostream>
#include <cassert>
#include <vector>
#include <algorithm>
#include <chrono>
#include <QCoreApplication>
#include <GL/gl.h>
#include <GL/glu.h>

#include "Mill.h"
#include "State.h"
#include "MillWindow.h"

const int MAP_SIZE=16;
#include "ballbitmap.h"
/*
unsigned char ballBitmap1[MAP_SIZE*MAP_SIZE*4];
unsigned char ballBitmap2[MAP_SIZE*MAP_SIZE*4];
*/

GLuint ball;

void createBall(float radius) {
  GLUquadricObj *ballQuadric;
  GLfloat  specular[] = { 0.4f, 0.4f, 0.4f, 1.0f};
  GLfloat  shine[] = { 10.0f };

  ball = glGenLists(1);
  glNewList(ball, GL_COMPILE);
  glEnable(GL_COLOR_MATERIAL);
  glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
  glMaterialfv(GL_FRONT, GL_SHININESS, shine);
  /*  glColor3f(1.0f,0.8f,0.8f);
  glColor3f(1.0f,0.0f,0.0f);*/
  ballQuadric=gluNewQuadric();
  gluQuadricNormals(ballQuadric,(GLenum)GLU_SMOOTH);
  gluQuadricDrawStyle(ballQuadric,(GLenum)GLU_FILL);
  //  gluSphere(ballQuadric,radius,10,5);
  //  gluSphere(ballQuadric,radius,14,7);
  gluSphere(ballQuadric,radius,30,15);
  gluDeleteQuadric(ballQuadric);
  //  glDisable(GL_COLOR_MATERIAL);
  glEndList();
}
/*
void getBitmap(unsigned char *ballBitmap,int w,int h) {
  glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
  glPushMatrix();
  glTranslatef(0,0,-9);
  glCallList(ball);
  glPopMatrix();
  glFlush();
  glReadBuffer(GL_BACK);
  glReadPixels( w/2-MAP_SIZE/2,h/2-MAP_SIZE/2,
		MAP_SIZE,MAP_SIZE,GL_RGBA,GL_UNSIGNED_BYTE,
		ballBitmap );
  cout << "unsigned char table [] {" << endl;
  for(int i=0;i<(MAP_SIZE*MAP_SIZE*4);i+=4) {
    if(ballBitmap[i]==0 &&
       ballBitmap[i+1]==0 &&
       ballBitmap[i+2]==0 )
      ballBitmap[i+3]=0;
    cout << (int)ballBitmap[i] << ",";
    cout << (int)ballBitmap[i+1] << ",";
    cout << (int)ballBitmap[i+2] << ",";
    cout << (int)ballBitmap[i+3] << "," << endl;
  }
  cout << endl;
}
*/

void Mill::init() {
  static bool first=true;

  int i;
  field=new Field(loadTexture("wood.tif"),(float)20,(float)2.3,(float)0.3);
  redisplay=true;
  stateInd=0;
  for(i=0;i<MAX_STATES;i++) {
    state[i]=NULL;
  }
  state[0]=new State(field);

  GLfloat  ambient[] = { 0.3f, 0.3f, 0.3f, 1.0f};
  GLfloat  diffuse[] = { 0.7f, 0.7f, 0.7f, 1.0f};
  GLfloat  specular[] = { 0.0f, 0.0f, 0.0f, 1.0f};
  GLfloat  shine[] = { 0.0f };

  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);
  glEnable(GL_AUTO_NORMAL);
  glEnable(GL_DEPTH_TEST);
  glEnable(GL_CULL_FACE);
  glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER,1);

  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
  glTexParameteri(GL_TEXTURE_2D, 
		  GL_TEXTURE_MIN_FILTER,
		  GL_LINEAR_MIPMAP_NEAREST);
  glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
  glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
  glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
  glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
  glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);

  glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
  glMaterialfv(GL_FRONT, GL_AMBIENT,   ambient);
  glMaterialfv(GL_FRONT, GL_DIFFUSE,   diffuse);
  glMaterialfv(GL_FRONT, GL_SPECULAR,  specular);
  glMaterialfv(GL_FRONT, GL_SHININESS, shine);
  createBall((float).9);
  //  createBall(barWidth*3);
  glMatrixMode(GL_MODELVIEW);
  //  glPushMatrix();
  //  glTranslatef(0.0f, 0.0f, -30.0f);
  glHint(GL_FOG_HINT,GL_NICEST);
  glFogf(GL_FOG_DENSITY,(float)0.02);
  glFogi(GL_FOG_MODE,GL_EXP);
  glLoadIdentity();

//  glEnable(GL_FOG);
  glTranslatef(0.0f, 0.0f, -30.0f);
  glClearColor(0,0,0,1);

  /*
  if(first) {
    glColor3f(1.0f,0.6f,0.0f);
    cout << "1 " << getWidth() << " " << getHeight() << endl;
    getBitmap(ballBitmap1,getWidth(),getHeight());
    glColor3f(0.7f,0.7f,0.7f);
    getBitmap(ballBitmap2,getWidth(),getHeight());
    first=false;
  }
  */
  glClearColor((float)0,(float)0,(float)0.2,(float)1);
}

double bx=0,by=0,bz=10;

void Mill::idle() {
  if(redisplay) {
    draw();
//    glutPostRedisplay();
  }
}

void Mill::draw() {
  static float w;
  int i;

  redisplay=false;
  const GLfloat colamb[3] = { 0.2f, 2.0f, 2.0f };
  const GLfloat colspec[3] = { 0.5f, 0.5f, 0.5f };
  const GLfloat lightpos[4] = { 4.0f, 4.0f, 10.0f,0.0f };

  // Festlegung der Lichtquellenparameter
  glLightfv(GL_LIGHT1, GL_AMBIENT, &colamb[0]);
  glLightfv(GL_LIGHT1, GL_SPECULAR, &colspec[0]);
  glLightfv(GL_LIGHT1, GL_POSITION, &lightpos[0]);
  glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

  // !!!!!!!!!!!!!
  glMatrixMode(GL_PROJECTION);
  glPushMatrix();
  glLoadIdentity();
  gluOrtho2D(0,getWidth(),0,getHeight()); 
  glMatrixMode(GL_MODELVIEW);
  glDepthMask(GL_FALSE);
  glEnable(GL_BLEND);
  glPushMatrix();
  glLoadIdentity();
  glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

  for(i=0;i<state[stateInd]->stones[1].toSet;i++) {
    glRasterPos3f(i*16,0,0);
    glDrawPixels(MAP_SIZE,MAP_SIZE,GL_RGBA,GL_UNSIGNED_BYTE,
		  ballBitmap1 );
  }
  for(i=0;
      i<(state[stateInd]->stones[1].left-state[stateInd]->stones[1].toSet);
      i++) {
    glRasterPos3f(MAX_STONES*16-i*16,0,0);
    glDrawPixels(MAP_SIZE,MAP_SIZE,GL_RGBA,GL_UNSIGNED_BYTE,
		  ballBitmap1 );
  }
  for(i=0;i<state[stateInd]->stones[2].toSet;i++) {
    glRasterPos3f(i*16,16,0);
    glDrawPixels(MAP_SIZE,MAP_SIZE,GL_RGBA,GL_UNSIGNED_BYTE,
		  ballBitmap2 );
  }
  for(i=0;
      i<(state[stateInd]->stones[2].left-state[stateInd]->stones[2].toSet);
      i++) {
    glRasterPos3f(MAX_STONES*16-i*16,16,0);
    glDrawPixels(MAP_SIZE,MAP_SIZE,GL_RGBA,GL_UNSIGNED_BYTE,
		  ballBitmap2 );
  }

  glPopMatrix();
  glDisable(GL_BLEND);
  glDepthMask(GL_TRUE);
  glMatrixMode(GL_PROJECTION);
  glPopMatrix();
  glMatrixMode(GL_MODELVIEW);
  // !!!!!!!!!!!!!

  field->draw();
  glFinish();
  char *farbe1,*farbe2;
  char text[100];
  if(state[stateInd]->color==1) {
    farbe1="Yellow";
    farbe2="White";
  } else {
    farbe2="Yellow";
    farbe1="White";
  }
  switch(state[stateInd]->action) {
  case SET:         sprintf(text,"%s place a new stone",farbe1); break;
  case REMOVE:      sprintf(text,"%s take a stone from %s.",farbe2,farbe1); break;
  case MOVE_REMOVE: sprintf(text,"%s select a stone to move",farbe1); break;
  case MOVE_SET:    sprintf(text,"%s place the stone",farbe1); break;
  case JUMP_REMOVE: sprintf(text,"%s select a stone to jump",farbe1); break;
  case JUMP_SET:    sprintf(text,"%s place the stone on a free place ",farbe1); break;
  }
  millWindow->setStatus((char*)text);


}

void Mill::specialInput( int k, int x, int y ) {
}

bool firstCall=true;
bool rotate=false;
float data_xold,data_yold;

int Mill::mouseFunc(int button,int state,int mx,int my) {
  int rc=0;
  if(button==GLUT_RIGHT_BUTTON && state==GLUT_DOWN) {
    FieldPos *pos=field->getPos(mx,getHeight()-my);
    rc=doMove(pos);
    redisplay=true;
    return rc;
  }
  if(button==GLUT_LEFT_BUTTON && state==GLUT_DOWN) {
    firstCall=true;
    rotate=true;
//    glutSetCursor(GLUT_CURSOR_CYCLE);
    return 0;
  }
  if(button==GLUT_LEFT_BUTTON && state==GLUT_UP) {
    rotate=false;
//    glutSetCursor(GLUT_CURSOR_INHERIT);
    return 0;
  }
  return 0;
}

void Mill::motionFunc(int mx,int my) {
  if(!rotate)
    return;
  glMatrixMode(GL_MODELVIEW);

  float p1[3],p2[3];

  float x,y,z;
  float l;
  float ww, wh;
  float axis[3];
  float angle,sina;
  float c;
  float f;
  float mouseX=(float)mx;
  float mouseY=(float)my;

  if(firstCall == true) {
    data_xold = mouseX;
    data_yold = mouseY;
    firstCall = false;
  }
  
  if( (data_xold==mouseX) &&
      (data_yold==mouseY) ) {
    return;
  }

  ww = float(getWidth());
  wh = float(getHeight());

  // Es werden zwei normierte Vektoren berechnet.

  // Vektor fuer alte Mausposition
  x = (data_xold * 2 - ww) / ww;
  y = (wh - data_yold * 2) / wh;
  l = x*x + y*y;
  if ( l > 1.0 ) {  
    // Auf Laenge 1 setzen. Z wird dann 0
    l=(float)sqrt(l);
    x/=l;y/=l;l=1.0;
  }
  z = (float)(1.0 - sqrt( l ));
  p1[0]=x / (float)sqrt( l + z*z );
  p1[1]=y / (float)sqrt( l + z*z );
  p1[2]=z / (float)sqrt( l + z*z );

  // Vektor fuer neue Mausposition
  x = (mouseX * 2 - ww) / ww;
  y = (wh - mouseY * 2) / wh;
  l = x*x + y*y;
  if ( l > 1.0 ) {
    // Auf Laenge 1 setzen. Z wird dann 0
    l=(float)sqrt(l);
    x/=l;y/=l;l=1.0;
  }
  z = 1.0 - sqrt( l );
  p2[0]=x / (float)sqrt( l + z*z );
  p2[1]=y / (float)sqrt( l + z*z );
  p2[2]=z / (float)sqrt( l + z*z );

  axis[0] = p2[1]*p1[2] - p1[1]*p2[2]; 
  axis[1] = p2[2]*p1[0] - p1[2]*p2[0];
  axis[2] = p2[0]*p1[1] - p1[0]*p2[1];

  // Winkel zwischen den Vektoren
  c = p1[0] * p2[0] + p1[1] * p2[1] + p1[2] * p2[2];
  if(c>0.9999)
    angle = 0;
  else
    angle = acos( c );

  // Fuer sehr kleine Winkel nicht berechnen
  if(angle < 0.001)
    return;

  // Axis normieren
  sina = sqrt( axis[0]*axis[0] + axis[1]*axis[1] + axis[2]*axis[2] );
  axis[0] = axis[0] / sina;
  axis[1] = axis[1] / sina;
  axis[2] = axis[2] / sina;

  // alte Position auf neue Position setzen
  data_xold = mouseX;
  data_yold = mouseY;
  
  glMatrixMode(GL_MODELVIEW);

  glLoadIdentity();
  glRotatef(-angle*180/M_PI,axis[0],axis[1],axis[2]);
  glMultMatrixf(orientation);
  glGetFloatv(GL_MODELVIEW_MATRIX,orientation);

  glLoadIdentity();
  glTranslatef(0.0f, 0.0f, -30.0f);
  glMultMatrixf(orientation);
  redisplay=true;
}

int Mill::doMove(FieldPos *pos) {
  State *newState;
  int i;
  if( (newState=state[stateInd]->setMove(pos)) ) {
    for(i=stateInd+1;i<MAX_STATES;i++) {
      if(state[i]) {
        delete state[i];
        state[i]=NULL;
      }
    }
    state[++stateInd]=newState;
    redisplay=true;
    if( ((newState->action) == REMOVE) && 
        ((newState->stones[ newState->color ].left)==3)
      ) {
      return newState->color;
    }
  } else {
    millWindow->showBeep();
  }
  return 0;
}

void Mill::undoMove() {
  while(stateInd>0) {
    state[--stateInd]->undoMove();
    redisplay=true;
    switch(state[stateInd]->action) {
    case MOVE_SET:
    case JUMP_SET:
      break;
    default:
      return;
    }
  }
}

void Mill::redoMove() {
  while(state[stateInd+1]!=NULL) {
    state[stateInd++]->redoMove();
    redisplay=true;
    switch(state[stateInd-1]->action) {
    case MOVE_REMOVE:
    case JUMP_REMOVE:
      break;
    default:
      return;
    }
  }
}

// ==========================================
// AI Playing Opponent Implementation
// ==========================================

struct AiMove {
  FieldPos* clicks[3];
  int clickCount;
};

// Helper: Check if two positions are adjacent
static bool areAdjacent(FieldPos* p1, FieldPos* p2) {
  int len = std::abs(p1->a1 - p2->a1) +
            std::abs(p1->b1 - p2->b1) +
            std::abs(p1->c1 - p2->c1) +
            std::abs(p1->d1 - p2->d1);
  return len == 1;
}

// Helper: Generate all legal moves for state S
static std::vector<AiMove> getLegalMoves(State* S, Field* field) {
  std::vector<AiMove> legalMoves;
  FieldPos* allPos[60];
  int posCount = field->getValidPositions(allPos);
  
  // Backup board and state
  int backupStatuses[60];
  for (int i = 0; i < posCount; i++) {
    backupStatuses[i] = allPos[i]->status;
  }
  State backupState = *S;
  
  auto restore = [&]() {
    for (int i = 0; i < posCount; i++) {
      allPos[i]->status = backupStatuses[i];
    }
    *S = backupState;
  };
  
  int activeColor = S->color;
  if (S->action == REMOVE) {
    activeColor = 3 - S->color;
  }
  int opponentColor = 3 - activeColor;
  
  if (S->action == SET) {
    for (int i = 0; i < posCount; i++) {
      FieldPos* c1 = allPos[i];
      if (c1->status != 0) continue;
      
      State* s1 = S->setMove(c1);
      if (s1 != nullptr) {
        if (s1->action == REMOVE) {
          // A mill was formed, we need c2 to remove an opponent stone
          for (int j = 0; j < posCount; j++) {
            FieldPos* c2 = allPos[j];
            if (c2->status != opponentColor) continue;
            
            // Check if removing c2 is legal
            State* s2 = s1->setMove(c2);
            if (s2 != nullptr) {
              AiMove move;
              move.clicks[0] = c1;
              move.clicks[1] = c2;
              move.clickCount = 2;
              legalMoves.push_back(move);
              delete s2;
            }
            // Restore board and S state for next c2
            restore();
            delete s1;
            s1 = S->setMove(c1); // re-simulate s1
          }
        } else {
          AiMove move;
          move.clicks[0] = c1;
          move.clickCount = 1;
          legalMoves.push_back(move);
        }
        delete s1;
      }
      restore();
    }
  } else if (S->action == MOVE_REMOVE || S->action == JUMP_REMOVE) {
    for (int i = 0; i < posCount; i++) {
      FieldPos* c1 = allPos[i];
      if (c1->status != activeColor) continue;
      
      State* s1 = S->setMove(c1);
      if (s1 != nullptr) {
        for (int j = 0; j < posCount; j++) {
          FieldPos* c2 = allPos[j];
          if (c2->status != 0) continue;
          
          State* s2 = s1->setMove(c2);
          if (s2 != nullptr) {
            if (s2->action == REMOVE) {
              for (int k = 0; k < posCount; k++) {
                FieldPos* c3 = allPos[k];
                if (c3->status != opponentColor) continue;
                
                State* s3 = s2->setMove(c3);
                if (s3 != nullptr) {
                  AiMove move;
                  move.clicks[0] = c1;
                  move.clicks[1] = c2;
                  move.clicks[2] = c3;
                  move.clickCount = 3;
                  legalMoves.push_back(move);
                  delete s3;
                }
                restore();
                delete s1; s1 = S->setMove(c1);
                delete s2; s2 = s1->setMove(c2);
              }
            } else {
              AiMove move;
              move.clicks[0] = c1;
              move.clicks[1] = c2;
              move.clickCount = 2;
              legalMoves.push_back(move);
            }
            delete s2;
          }
          restore();
          delete s1; s1 = S->setMove(c1);
        }
        delete s1;
      }
      restore();
    }
  }
  
  return legalMoves;
}

// Heuristics: Count mills
static int countMills(Field* field, int color) {
  FieldPos* allPos[60];
  int posCount = field->getValidPositions(allPos);
  int millPoints = 0;
  for (int i = 0; i < posCount; i++) {
    FieldPos* pos = allPos[i];
    for (int a = 0; a < 4; a++) {
      if (pos->mill[a][0]->status == color &&
          pos->mill[a][1]->status == color &&
          pos->mill[a][2]->status == color) {
        millPoints++;
      }
    }
  }
  return millPoints / 3;
}

// Heuristics: Count blocked stones
static int countBlockedStones(Field* field, int color) {
  FieldPos* allPos[60];
  int posCount = field->getValidPositions(allPos);
  int blockedCount = 0;
  for (int i = 0; i < posCount; i++) {
    FieldPos* p1 = allPos[i];
    if (p1->status != color) continue;
    
    bool canMove = false;
    for (int j = 0; j < posCount; j++) {
      FieldPos* p2 = allPos[j];
      if (p2->status == 0 && areAdjacent(p1, p2)) {
        canMove = true;
        break;
      }
    }
    if (!canMove) {
      blockedCount++;
    }
  }
  return blockedCount;
}

// Heuristics: Count 2-stone configurations
static int countTwoStoneConfigs(Field* field, int color) {
  FieldPos* allPos[60];
  int posCount = field->getValidPositions(allPos);
  int count = 0;
  for (int i = 0; i < posCount; i++) {
    FieldPos* pos = allPos[i];
    for (int a = 0; a < 4; a++) {
      int ownCount = 0;
      int emptyCount = 0;
      for (int k = 0; k < 3; k++) {
        if (pos->mill[a][k]->status == color) ownCount++;
        else if (pos->mill[a][k]->status == 0) emptyCount++;
      }
      if (ownCount == 2 && emptyCount == 1) {
        count++;
      }
    }
  }
  return count / 3;
}

// Evaluation function
static int evaluateState(State* S, Field* field, int aiColor) {
  int opponentColor = 3 - aiColor;
  
  if (S->stones[opponentColor].toSet == 0 && S->stones[opponentColor].left < 3) {
    return 1000000;
  }
  if (S->stones[aiColor].toSet == 0 && S->stones[aiColor].left < 3) {
    return -1000000;
  }
  
  int score = 0;
  
  // 1. Material score
  int materialWeight = 1000;
  score += S->stones[aiColor].left * materialWeight;
  score -= S->stones[opponentColor].left * materialWeight;
  
  // 2. Mills score
  int millWeight = 200;
  score += countMills(field, aiColor) * millWeight;
  score -= countMills(field, opponentColor) * millWeight;
  
  // 3. Blocked stones score
  if (S->stones[aiColor].toSet == 0) {
    int blockedWeight = 50;
    score -= countBlockedStones(field, aiColor) * blockedWeight;
    score += countBlockedStones(field, opponentColor) * blockedWeight;
  }
  
  // 4. Threats
  int threatWeight = 80;
  score += countTwoStoneConfigs(field, aiColor) * threatWeight;
  score -= countTwoStoneConfigs(field, opponentColor) * threatWeight;
  
  return score;
}

// Alpha-Beta Minimax
static int alphaBeta(State* S, Field* field, int depth, int alpha, int beta, bool maximizingPlayer, int aiColor, AiMove& bestMove, int& evaluatedNodes) {
  evaluatedNodes++;
  if (depth == 0 || (S->stones[1].toSet == 0 && S->stones[1].left < 3) || (S->stones[2].toSet == 0 && S->stones[2].left < 3)) {
    return evaluateState(S, field, aiColor);
  }
  
  std::vector<AiMove> moves = getLegalMoves(S, field);
  if (moves.empty()) {
    int activeColor = S->color;
    if (S->action == REMOVE) {
      activeColor = 3 - S->color;
    }
    if (activeColor == aiColor) {
      return -1000000;
    } else {
      return 1000000;
    }
  }
  
  FieldPos* allPos[60];
  int posCount = field->getValidPositions(allPos);
  
  int backupStatuses[60];
  for (int i = 0; i < posCount; i++) {
    backupStatuses[i] = allPos[i]->status;
  }
  State backupState = *S;
  
  auto restore = [&]() {
    for (int i = 0; i < posCount; i++) {
      allPos[i]->status = backupStatuses[i];
    }
    *S = backupState;
  };
  
  if (maximizingPlayer) {
    int maxEval = -2000000;
    AiMove localBestMove;
    if (!moves.empty()) localBestMove = moves[0];
    
    for (const auto& move : moves) {
      State* temp = S;
      for (int i = 0; i < move.clickCount; i++) {
        State* next = temp->setMove(move.clicks[i]);
        if (temp != S) delete temp;
        temp = next;
      }
      
      AiMove dummy;
      int eval = alphaBeta(temp, field, depth - 1, alpha, beta, false, aiColor, dummy, evaluatedNodes);
      if (temp != S) delete temp;
      
      restore();
      
      if (eval > maxEval) {
        maxEval = eval;
        localBestMove = move;
      }
      alpha = std::max(alpha, eval);
      if (beta <= alpha) {
        break;
      }
    }
    bestMove = localBestMove;
    return maxEval;
  } else {
    int minEval = 2000000;
    AiMove dummy;
    
    for (const auto& move : moves) {
      State* temp = S;
      for (int i = 0; i < move.clickCount; i++) {
        State* next = temp->setMove(move.clicks[i]);
        if (temp != S) delete temp;
        temp = next;
      }
      
      int eval = alphaBeta(temp, field, depth - 1, alpha, beta, true, aiColor, dummy, evaluatedNodes);
      if (temp != S) delete temp;
      
      restore();
      
      if (eval < minEval) {
        minEval = eval;
      }
      beta = std::min(beta, eval);
      if (beta <= alpha) {
        break;
      }
    }
    return minEval;
  }
}

bool Mill::isAiEnabled() {
  return millWindow->isAiEnabled();
}

int Mill::getAiColor() {
  return millWindow->getAiColor();
}

int Mill::getActivePlayerColor() {
  State* s = state[stateInd];
  if (s->action == REMOVE) {
    return 3 - s->color;
  } else {
    return s->color;
  }
}

bool Mill::isGameOver() {
  State* s = state[stateInd];
  for (int c = 1; c <= 2; c++) {
    if (s->stones[c].toSet == 0 && s->stones[c].left < 3) {
      return true;
    }
  }
  std::vector<AiMove> moves = getLegalMoves(s, field);
  if (moves.empty()) {
    return true;
  }
  return false;
}

int Mill::getWinner() {
  State* s = state[stateInd];
  if (s->stones[1].toSet == 0 && s->stones[1].left < 3) return 2;
  if (s->stones[2].toSet == 0 && s->stones[2].left < 3) return 1;
  
  std::vector<AiMove> moves = getLegalMoves(s, field);
  if (moves.empty()) {
    return 3 - getActivePlayerColor();
  }
  return 0;
}

static QString formatPos(FieldPos* pos) {
  if (!pos) return "N/A";
  return QString("C%1 (%2,%3,%4)")
      .arg(pos->a1)
      .arg(pos->b1)
      .arg(pos->c1)
      .arg(pos->d1);
}

static QString describeMove(const AiMove& move) {
  if (move.clickCount == 1) {
    return QString("Place at %1").arg(formatPos(move.clicks[0]));
  }
  if (move.clickCount == 2) {
    if (move.clicks[0]->status == 0) {
      return QString("Place %1 & Cap %2")
          .arg(formatPos(move.clicks[0]))
          .arg(formatPos(move.clicks[1]));
    } else {
      return QString("Move %1 -> %2")
          .arg(formatPos(move.clicks[0]))
          .arg(formatPos(move.clicks[1]));
    }
  }
  if (move.clickCount == 3) {
    return QString("Move %1->%2 & Cap %3")
        .arg(formatPos(move.clicks[0]))
        .arg(formatPos(move.clicks[1]))
        .arg(formatPos(move.clicks[2]));
  }
  return "N/A";
}

void Mill::checkAndRunAi() {
  if (!isAiEnabled()) return;
  
  // Set UI to Thinking...
  millWindow->updateAiConsole("Thinking...", 0, 0, "Searching...", 0);
  QCoreApplication::processEvents();
  
  auto start = std::chrono::high_resolution_clock::now();
  int evaluatedNodes = 0;
  
  while (getActivePlayerColor() == getAiColor() && !isGameOver()) {
    AiMove bestMove;
    int eval = alphaBeta(state[stateInd], field, 2, -2000000, 2000000, true, getAiColor(), bestMove, evaluatedNodes);
    
    auto end = std::chrono::high_resolution_clock::now();
    int timeMs = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
    
    if (bestMove.clickCount > 0) {
      QString moveDesc = describeMove(bestMove);
      millWindow->updateAiConsole("Idle", evaluatedNodes, eval, moveDesc, timeMs);
      
      for (int i = 0; i < bestMove.clickCount; i++) {
        doMove(bestMove.clicks[i]);
      }
    } else {
      millWindow->updateAiConsole("Idle", evaluatedNodes, eval, "No Moves Available", timeMs);
      break;
    }
  }
}






