#ifndef FIELD_H
#define FIELD_H

struct FieldPos {
  float pos[3];
  int status;
  FieldPos *mill[4][3];
  int a1,b1,c1,d1;
  int a2,b2,c2,d2;
};

class Field {
public:
  Field(GLuint texture,float fWidth,float fDist,float bWidth);
  void draw();
  FieldPos *getPos(double x,double y);
  int getValidPositions(FieldPos *list[]);
private:
  struct {
    struct FieldPos field[3][3][3];
  } qube[3];

  float pos[3][3][3][3];
  float fieldDist,fieldWidth,barWidth;
  GLuint fieldList;
  GLuint createSide(float s,float w);
  GLuint createBar();
  GLuint createQube(float s,float w);
};

#endif





