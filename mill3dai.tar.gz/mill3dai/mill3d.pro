QT += widgets opengl

TARGET = mill3d
TEMPLATE = app

SOURCES += \
    main.cc \
    MillWindow.cc \
    MillGLWidget.cc \
    Field.cc \
    Mill.cc \
    State.cc \
    Texture.cc \
    Ginit.cc

HEADERS += \
    MillWindow.h \
    MillGLWidget.h \
    Field.h \
    Mill.h \
    State.h \
    Ginit.h \
    ballbitmap.h \
    rules.h

LIBS += -lGL -lGLU
