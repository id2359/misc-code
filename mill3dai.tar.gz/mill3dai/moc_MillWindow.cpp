/****************************************************************************
** Meta object code from reading C++ file 'MillWindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "MillWindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MillWindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MillWindow_t {
    QByteArrayData data[31];
    char stringdata0[284];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MillWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MillWindow_t qt_meta_stringdata_MillWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MillWindow"
QT_MOC_LITERAL(1, 11, 7), // "newGame"
QT_MOC_LITERAL(2, 19, 0), // ""
QT_MOC_LITERAL(3, 20, 8), // "undoGame"
QT_MOC_LITERAL(4, 29, 8), // "redoGame"
QT_MOC_LITERAL(5, 38, 8), // "exitGame"
QT_MOC_LITERAL(6, 47, 4), // "help"
QT_MOC_LITERAL(7, 52, 5), // "about"
QT_MOC_LITERAL(8, 58, 9), // "glversion"
QT_MOC_LITERAL(9, 68, 15), // "toggleStatusBar"
QT_MOC_LITERAL(10, 84, 13), // "toggleToolBar"
QT_MOC_LITERAL(11, 98, 11), // "toggleSolid"
QT_MOC_LITERAL(12, 110, 13), // "toggleTexture"
QT_MOC_LITERAL(13, 124, 9), // "toggleFog"
QT_MOC_LITERAL(14, 134, 9), // "setStatus"
QT_MOC_LITERAL(15, 144, 5), // "char*"
QT_MOC_LITERAL(16, 150, 3), // "msg"
QT_MOC_LITERAL(17, 154, 8), // "showBeep"
QT_MOC_LITERAL(18, 163, 11), // "isAiEnabled"
QT_MOC_LITERAL(19, 175, 10), // "getAiColor"
QT_MOC_LITERAL(20, 186, 12), // "setAiEnabled"
QT_MOC_LITERAL(21, 199, 7), // "enabled"
QT_MOC_LITERAL(22, 207, 10), // "setAiColor"
QT_MOC_LITERAL(23, 218, 5), // "color"
QT_MOC_LITERAL(24, 224, 15), // "updateAiConsole"
QT_MOC_LITERAL(25, 240, 6), // "status"
QT_MOC_LITERAL(26, 247, 5), // "nodes"
QT_MOC_LITERAL(27, 253, 5), // "score"
QT_MOC_LITERAL(28, 259, 8), // "bestMove"
QT_MOC_LITERAL(29, 268, 6), // "timeMs"
QT_MOC_LITERAL(30, 275, 8) // "toggleAi"

    },
    "MillWindow\0newGame\0\0undoGame\0redoGame\0"
    "exitGame\0help\0about\0glversion\0"
    "toggleStatusBar\0toggleToolBar\0toggleSolid\0"
    "toggleTexture\0toggleFog\0setStatus\0"
    "char*\0msg\0showBeep\0isAiEnabled\0"
    "getAiColor\0setAiEnabled\0enabled\0"
    "setAiColor\0color\0updateAiConsole\0"
    "status\0nodes\0score\0bestMove\0timeMs\0"
    "toggleAi"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MillWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      20,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  114,    2, 0x0a /* Public */,
       3,    0,  115,    2, 0x0a /* Public */,
       4,    0,  116,    2, 0x0a /* Public */,
       5,    0,  117,    2, 0x0a /* Public */,
       6,    0,  118,    2, 0x0a /* Public */,
       7,    0,  119,    2, 0x0a /* Public */,
       8,    0,  120,    2, 0x0a /* Public */,
       9,    0,  121,    2, 0x0a /* Public */,
      10,    0,  122,    2, 0x0a /* Public */,
      11,    0,  123,    2, 0x0a /* Public */,
      12,    0,  124,    2, 0x0a /* Public */,
      13,    0,  125,    2, 0x0a /* Public */,
      14,    1,  126,    2, 0x0a /* Public */,
      17,    0,  129,    2, 0x0a /* Public */,
      18,    0,  130,    2, 0x0a /* Public */,
      19,    0,  131,    2, 0x0a /* Public */,
      20,    1,  132,    2, 0x0a /* Public */,
      22,    1,  135,    2, 0x0a /* Public */,
      24,    5,  138,    2, 0x0a /* Public */,
      30,    0,  149,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 15,   16,
    QMetaType::Void,
    QMetaType::Bool,
    QMetaType::Int,
    QMetaType::Void, QMetaType::Bool,   21,
    QMetaType::Void, QMetaType::Int,   23,
    QMetaType::Void, QMetaType::QString, QMetaType::Int, QMetaType::Int, QMetaType::QString, QMetaType::Int,   25,   26,   27,   28,   29,
    QMetaType::Void,

       0        // eod
};

void MillWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MillWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->newGame(); break;
        case 1: _t->undoGame(); break;
        case 2: _t->redoGame(); break;
        case 3: _t->exitGame(); break;
        case 4: _t->help(); break;
        case 5: _t->about(); break;
        case 6: _t->glversion(); break;
        case 7: _t->toggleStatusBar(); break;
        case 8: _t->toggleToolBar(); break;
        case 9: _t->toggleSolid(); break;
        case 10: _t->toggleTexture(); break;
        case 11: _t->toggleFog(); break;
        case 12: _t->setStatus((*reinterpret_cast< char*(*)>(_a[1]))); break;
        case 13: _t->showBeep(); break;
        case 14: { bool _r = _t->isAiEnabled();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 15: { int _r = _t->getAiColor();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 16: _t->setAiEnabled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 17: _t->setAiColor((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->updateAiConsole((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< const QString(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5]))); break;
        case 19: _t->toggleAi(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MillWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MillWindow.data,
    qt_meta_data_MillWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MillWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MillWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MillWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MillWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 20)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 20;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
