#ifndef MILLWINDOW_H
#define MILLWINDOW_H

#include <QMainWindow>
#include "MillGLWidget.h"

class QToolBar;
class QMenu;
class QGLWidget;
class Mill;
class QAction;
class QLabel;

class MillWindow: public QMainWindow
{
    Q_OBJECT
public:
    MillWindow();
    ~MillWindow();
    
public slots:
    void newGame();
    void undoGame();
    void redoGame();
    void exitGame();
    void help();
    void about();
    void glversion();

    void toggleStatusBar();
    void toggleToolBar();
    void toggleSolid();
    void toggleTexture();
    void toggleFog();

    void setStatus(char *msg);
    void showBeep();
    
    bool isAiEnabled() const { return aiEnabled; }
    int getAiColor() const { return aiColor; }
    void setAiEnabled(bool enabled) { aiEnabled = enabled; }
    void setAiColor(int color) { aiColor = color; }
    void updateAiConsole(const QString &status, int nodes, int score, const QString &bestMove, int timeMs);

public slots:
    void toggleAi();
private:
    QToolBar   *gameTools;
    QMenu      *gameMenu;
    QMenu      *controlMenu;
    QMenu      *viewMenu;
    QMenu      *helpMenu;
    QGLWidget  *glWidget;
    QAction    *tbAction;
    QAction    *sbAction;
    QAction    *solidAction;
    QAction    *textureAction;
    QAction    *fogAction;
    Mill *mill;
    bool aiEnabled;
    int aiColor;
    QAction    *aiAction;
    
    QLabel *aiStatusLabel;
    QLabel *aiDepthLabel;
    QLabel *aiNodesLabel;
    QLabel *aiScoreLabel;
    QLabel *aiBestMoveLabel;
    QLabel *aiTimeLabel;
};

#endif

