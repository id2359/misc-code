#!/bin/sh

DISPLAY=:0 ./mill3d
