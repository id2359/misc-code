#include <iostream>
#include <cstdlib>
#include <cmath>
#include <cassert>
#include <GL/gl.h>
#include <GL/glu.h>
#include "Field.h"

extern GLuint ball;


//---------------------------------------------------------------------------
// Create one Side of a qube
//---------------------------------------------------------------------------
GLuint Field::createSide(float s,float w) {
  float si=10;
  float a=(s+s)/si;
  float b=(w+w)/si;
  GLuint listname = glGenLists(1);
  
  glNewList(listname, GL_COMPILE);
  glMatrixMode(GL_MODELVIEW);
  glPushMatrix();
  glTranslatef(0.0f, s, -s);
  glBegin(GL_POLYGON);
  glNormal3f(0.0f, 0.0f, -1.0f);
  glTexCoord2f(0  ,0);  glVertex3f( -s-w, w,-w );
  glTexCoord2f(a  ,0);  glVertex3f(  s+w, w,-w );
  glTexCoord2f(a-b,b*8);  glVertex3f(  s-w,-w,-w );
  glTexCoord2f(b  ,b*8);  glVertex3f( -s+w,-w,-w );
  glEnd();
  glBegin(GL_POLYGON);
  glNormal3f(0.0f, -1.0f, 0.0f);
  glTexCoord2f(b  ,b*8);  glVertex3f( -s+w,-w,-w );
  glTexCoord2f(a-b,b*8);  glVertex3f(  s-w,-w,-w );
  glTexCoord2f(a-b,0);  glVertex3f(  s-w,-w, w );
  glTexCoord2f(b  ,0);  glVertex3f( -s+w,-w, w );
  glEnd();
  glBegin(GL_POLYGON);
  glNormal3f(0.0f, 0.0f, 1.0f);
  glTexCoord2f(b  ,b*8);  glVertex3f( -s+w,-w, w );
  glTexCoord2f(a-b,b*8);  glVertex3f(  s-w,-w, w );
  glTexCoord2f(a-b,0);  glVertex3f(  s-w, w, w );
  glTexCoord2f(b  ,0);  glVertex3f( -s+w, w, w );
  glEnd();
  glBegin(GL_POLYGON);
  glNormal3f(0.0f, 1.0f, 0.0f);
  glTexCoord2f(a-b,0); glVertex3f( -s+w, w, w );
  glTexCoord2f(b  ,0); glVertex3f(  s-w, w, w );
  glTexCoord2f(0  ,b*8); glVertex3f(  s+w, w,-w );
  glTexCoord2f(a  ,b*8); glVertex3f( -s-w, w,-w );
  glEnd();
  glPopMatrix();
  glEndList();
  return listname;
}

//---------------------------------------------------------------------------
// Create bar
//---------------------------------------------------------------------------
GLuint Field::createBar() {
  float si=10;
  float s=(float)sqrt(2*fieldDist*fieldDist);
  float w=barWidth/2;
  
  float a=(s+s)/si;
  float b=(w+w)/si;
  GLuint listname1 = glGenLists(1);
  GLuint listname2 = glGenLists(1);
  GLuint listname3 = glGenLists(1);
  
  glNewList(listname1, GL_COMPILE);
  glMatrixMode(GL_MODELVIEW);
  glPushMatrix();
  glRotatef(45, 0.0f, 0.0f, 1.0f);
  glTranslatef((float)sqrt(2*(fieldWidth/2.0-fieldDist)*(fieldWidth/2.0-fieldDist))
    , 0, 0);
  glBegin(GL_POLYGON);
  glNormal3f(0.0f, 0.0f, -1.0f);
  glTexCoord2f(0  ,0);  glVertex3f( -s, w,-w );
  glTexCoord2f(a  ,0);  glVertex3f(  s, w,-w );
  glTexCoord2f(a  ,b);  glVertex3f(  s,-w,-w );
  glTexCoord2f(0  ,b);  glVertex3f( -s,-w,-w );
  glEnd();
  glBegin(GL_POLYGON);
  glNormal3f(0.0f, -1.0f, 0.0f);
  glTexCoord2f(0  ,b);  glVertex3f( -s,-w,-w );
  glTexCoord2f(a  ,b);  glVertex3f(  s,-w,-w );
  glTexCoord2f(a  ,0);  glVertex3f(  s,-w, w );
  glTexCoord2f(0  ,0);  glVertex3f( -s,-w, w );
  glEnd();
  glBegin(GL_POLYGON);
  glNormal3f(0.0f, 0.0f, 1.0f);
  glTexCoord2f(0  ,b);  glVertex3f( -s,-w, w );
  glTexCoord2f(a  ,b);  glVertex3f(  s,-w, w );
  glTexCoord2f(a  ,0);  glVertex3f(  s, w, w );
  glTexCoord2f(0  ,0);  glVertex3f( -s, w, w );
  glEnd();
  glBegin(GL_POLYGON);
  glNormal3f(0.0f, 1.0f, 0.0f);
  glTexCoord2f(a  ,0); glVertex3f( -s, w, w );
  glTexCoord2f(0  ,0); glVertex3f(  s, w, w );
  glTexCoord2f(0  ,b); glVertex3f(  s, w,-w );
  glTexCoord2f(a  ,b); glVertex3f( -s, w,-w );
  glEnd();
  glPopMatrix();
  glEndList();
  
  glNewList(listname2, GL_COMPILE);
  glMatrixMode(GL_MODELVIEW);
  glPushMatrix();
  glCallList(listname1);
  glRotatef(90, 0.0f, 0.0f, 1.0f);
  glCallList(listname1);
  glRotatef(90, 0.0f, 0.0f, 1.0f);
  glCallList(listname1);
  glRotatef(90, 0.0f, 0.0f, 1.0f);
  glCallList(listname1);
  glPopMatrix();
  glEndList();
  
  glNewList(listname3, GL_COMPILE);
  glMatrixMode(GL_MODELVIEW);
  glCallList(listname2);
  glPushMatrix();
  glRotatef(90, 0.0f, 1.0f, 0.0f);
  glCallList(listname2);
  glPopMatrix();
  glPushMatrix();
  glRotatef(90, 1.0f, 0.0f, 0.0f);
  glCallList(listname2);
  glPopMatrix();
  glEndList();
  return listname3;
}

//---------------------------------------------------------------------------
// Create one side of a qube
//---------------------------------------------------------------------------
GLuint Field::createQube(float s,float w) {
  GLuint listname1;
  GLuint listname2 = glGenLists(1);
  GLuint listname3 = glGenLists(1);
  
  listname1 = createSide(s,w);
  
  glNewList(listname2, GL_COMPILE);
  glPushMatrix();
  glRotatef(180, 0.0f, 0.0f, 1.0f);
  glCallList(listname1);
  glRotatef(90, 0.0f, 0.0f, 1.0f);
  glCallList(listname1);
  glRotatef(90, 0.0f, 0.0f, 1.0f);
  glCallList(listname1);
  glPopMatrix();
  glEndList();
  
  glNewList(listname3, GL_COMPILE);
  glPushMatrix();
  glRotatef(90, 0.0f, 1.0f, 0.0f);
  glCallList(listname2);
  glRotatef(90, 0.0f, 1.0f, 0.0f);
  glCallList(listname2);
  glRotatef(90, 0.0f, 1.0f, 0.0f);
  glCallList(listname2);
  glRotatef(90, 0.0f, 1.0f, 0.0f);
  glCallList(listname2);
  glPopMatrix();
  glEndList();
  return listname3;
}

//---------------------------------------------------------------------------
// Create field
//---------------------------------------------------------------------------
Field::Field(GLuint texture,
             float fWidth,
             float fDist,
             float bWidth) {
  int q,fx,fy,fz;
  FieldPos *pos;
  
  fieldWidth=fWidth;
  fieldDist=fDist;
  barWidth=bWidth;
  // initialize field positions and status
  for(q=0;q<3;q++) {
    for(fx=0;fx<3;fx++) {
      for(fy=0;fy<3;fy++) {
        for(fz=0;fz<3;fz++) {
          qube[q].field[fx][fy][fz].a1=q;
          qube[q].field[fx][fy][fz].b1=fx;
          qube[q].field[fx][fy][fz].c1=fy;
          qube[q].field[fx][fy][fz].d1=fz;
          if((( fx==1) && (fy==1 || fz==1)) ||
	           (( fy==1) && (fx==1 || fz==1))) {
            qube[q].field[fx][fy][fz].status=-1;
            continue;
          }
          pos=&qube[q].field[fx][fy][fz];
          pos->status=0;
          pos->pos[0]=(fx-1)*(fieldWidth/2-q*fieldDist);
          pos->pos[1]=(fy-1)*(fieldWidth/2-q*fieldDist);
          pos->pos[2]=(fz-1)*(fieldWidth/2-q*fieldDist);
          
          if( fx==1 || fy==1 || fz==1) {
            pos->mill[0][0] = &qube[0].field[fx][fy][fz];
            pos->mill[0][1] = &qube[1].field[fx][fy][fz];
            pos->mill[0][2] = &qube[2].field[fx][fy][fz];
          } else {
            pos->mill[0][0] = &qube[0].field[1][1][1];
            pos->mill[0][1] = &qube[0].field[1][1][1];
            pos->mill[0][2] = &qube[0].field[1][1][1];
          }
          
          pos->mill[1][0] = &qube[q].field[0][fy][fz];
          pos->mill[1][1] = &qube[q].field[1][fy][fz];
          pos->mill[1][2] = &qube[q].field[2][fy][fz];
          
          pos->mill[2][0] = &qube[q].field[fx][0][fz];
          pos->mill[2][1] = &qube[q].field[fx][1][fz];
          pos->mill[2][2] = &qube[q].field[fx][2][fz];
          
          pos->mill[3][0] = &qube[q].field[fx][fy][0];
          pos->mill[3][1] = &qube[q].field[fx][fy][1];
          pos->mill[3][2] = &qube[q].field[fx][fy][2];
          
          qube[q].field[fx][fy][fz].status=0;
        }
      }
    }
  }
  // Create field paintlist
  float width=barWidth/2,size=fieldWidth/2;
  fieldList = glGenLists(1);
  GLuint q1 = createQube(fieldWidth/2            ,barWidth/2);
  GLuint q2 = createQube(fieldWidth/2-fieldDist  ,barWidth/2);
  GLuint q3 = createQube(fieldWidth/2-2*fieldDist,barWidth/2);
  GLuint bar = createBar();
  GLfloat  specular[] = { 0.0f, 0.0f, 0.0f, 1.0f};
  GLfloat  shine[] = { 0.0f };
  
  glNewList(fieldList, GL_COMPILE);
//  glEnable(GL_TEXTURE_2D);
  glEnable(GL_COLOR_MATERIAL);
  
  //  glEnable(GL_POLYGON_SMOOTH);
  //  glEnable(GL_BLEND);
  //  glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
  
  glPushMatrix();
  glBindTexture(GL_TEXTURE_2D,texture);
  glColor3f(1.0f,1.0f,1.0f);
  glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
  glMaterialfv(GL_FRONT, GL_SHININESS, shine);
  glCallList(q1);
  glCallList(q2);
  glCallList(q3);
  glPopMatrix();
  glPushMatrix();
  glCallList(bar);
  glPopMatrix();
//  glDisable(GL_TEXTURE_2D);
  /*  glDisable(GL_POLYGON_SMOOTH);
  glDisable(GL_BLEND);*/
  glEndList();
}

void Field::draw() {
  int q,fx,fy,fz;

  glPushAttrib(GL_TEXTURE_ENV);
  glDisable(GL_TEXTURE_2D);
  for(q=0;q<3;q++) {
    for(fx=0;fx<3;fx++) {
      for(fy=0;fy<3;fy++) {
        for(fz=0;fz<3;fz++) {
          if(qube[q].field[fx][fy][fz].status>0) {
            glPushMatrix();
            glTranslatef(qube[q].field[fx][fy][fz].pos[0],
              qube[q].field[fx][fy][fz].pos[1],
              qube[q].field[fx][fy][fz].pos[2]);
            if(qube[q].field[fx][fy][fz].status==1) {
              //	      glColor3f(1.0f,1.0f,0.8f);
              glColor3f(1.0f,0.6f,0.0f);
            } else {
              //	      glColor3f(0.1f,0.0f,0.0f);
              glColor3f(0.7f,0.7f,0.7f);
            }
            glCallList(ball);
            glPopMatrix();
          }
        }
      }
    }
  }
  glPopAttrib();
  glCallList(fieldList);
}

//---------------------------------------------------------------------------
// Get nearest pos
//---------------------------------------------------------------------------
FieldPos *Field::getPos(double x,double y) {
  double model[16];
  double proj[16];
  int vport[4];
  int q,fx,fy,fz;
  double bx,by,bz;
  double dist,minDist=1e20;
  FieldPos *fieldPos;
  
  // get transformation, projektion and viewport
  glGetDoublev(GL_MODELVIEW_MATRIX,model);
  glGetDoublev(GL_PROJECTION_MATRIX,proj);
  glGetIntegerv(GL_VIEWPORT,vport);
  
  for(q=0;q<3;q++) {
    for(fx=0;fx<3;fx++) {
      for(fy=0;fy<3;fy++) {
        for(fz=0;fz<3;fz++) {
          if(qube[q].field[fx][fy][fz].status>=0) {
            gluProject(qube[q].field[fx][fy][fz].pos[0],
              qube[q].field[fx][fy][fz].pos[1],
              qube[q].field[fx][fy][fz].pos[2],
              model,proj,vport,
              &bx,&by,&bz);
            dist=
              (bx-x)*(bx-x) +
              (by-y)*(by-y);
            if(dist<minDist) {
              fieldPos=&qube[q].field[fx][fy][fz];
              minDist=dist;
            }
          }
        }
      }
    }
  }
  return fieldPos;
}

int Field::getValidPositions(FieldPos *list[]) {
  int count = 0;
  for(int q=0; q<3; q++) {
    for(int fx=0; fx<3; fx++) {
      for(int fy=0; fy<3; fy++) {
        for(int fz=0; fz<3; fz++) {
          if(qube[q].field[fx][fy][fz].status >= 0) {
            list[count++] = &qube[q].field[fx][fy][fz];
          }
        }
      }
    }
  }
  return count;
}



