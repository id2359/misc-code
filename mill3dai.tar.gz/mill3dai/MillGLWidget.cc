#include <iostream>
#include <cstdio>
#include <QGLWidget>
#include <GL/gl.h>
#include "Ginit.h"

#include <QMouseEvent>
#include <QMessageBox>

#include "MillGLWidget.h"
#include "Mill.h"
#include "MillWindow.h"

MillGLWidget::MillGLWidget(QWidget *w,Mill *m,QGLFormat &f):QGLWidget(f,w)
{
  mill=m;
  millWindow=(MillWindow*)w;
}

void MillGLWidget::initializeGL() {
  mill->reshapeCB(width(),height());
  mill->init();
  glEnable(GL_TEXTURE_2D);
  glPolygonMode(GL_FRONT,GL_FILL);
  glEnable(GL_FOG);
}

void MillGLWidget::resizeGL( int w, int h ) {
  mill->reshapeCB(w,h);
}

void MillGLWidget::paintGL() {
  mill->draw();
}

void MillGLWidget::mouseMoveEvent(QMouseEvent *e) {
  mill->motionFunc(e->x(),e->y());
  if(mill->mustRedisplay()) {
    mill->draw();
    swapBuffers();
  }
}

void MillGLWidget::mousePressEvent(QMouseEvent *e) {
  char text[100];

  if(e->button()==Qt::LeftButton)
    mill->mouseFunc(GLUT_LEFT_BUTTON,GLUT_DOWN,e->x(),e->y());
  if(e->button()==Qt::RightButton) {
    mill->mouseFunc(GLUT_RIGHT_BUTTON,GLUT_DOWN,e->x(),e->y());
  }
  if(mill->mustRedisplay()) {
    mill->draw();
    swapBuffers();
  }

  int winner = mill->getWinner();
  if (winner) {
    if(winner==1) {
      sprintf(text,"Yellow is the winner");
    } else {
      sprintf(text,"White is the winner");
    }
    QMessageBox::information(this, "Mill", text);
    millWindow->newGame();
    return;
  }

  // If AI is enabled and it is AI's turn, run AI opponent
  if (mill->isAiEnabled()) {
    mill->checkAndRunAi();
    if(mill->mustRedisplay()) {
      mill->draw();
      swapBuffers();
    }
    winner = mill->getWinner();
    if (winner) {
      if(winner==1) {
        sprintf(text,"Yellow is the winner");
      } else {
        sprintf(text,"White is the winner");
      }
      QMessageBox::information(this, "Mill", text);
      millWindow->newGame();
      return;
    }
  }
}

void MillGLWidget::mouseReleaseEvent(QMouseEvent *e) {
  if(e->button()==Qt::LeftButton)
    mill->mouseFunc(GLUT_LEFT_BUTTON,GLUT_UP,e->x(),e->y());
  if(e->button()==Qt::RightButton) {
    mill->mouseFunc(GLUT_RIGHT_BUTTON,GLUT_UP,e->x(),e->y());
  }
  if(mill->mustRedisplay()) {
    mill->draw();
    swapBuffers();
  }
}

void MillGLWidget::setMill(Mill *m) {
  mill = m;
}





