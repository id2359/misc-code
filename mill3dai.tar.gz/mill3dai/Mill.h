#ifndef MILL_H
#define MILL_H
#include "Ginit.h"
#include "Field.h"
#include "State.h"

#define MAX_STATES 10000

class MillWindow;

class Mill :public GInit{
public:
  Mill(MillWindow *window):GInit(0,NULL,640,480) {
    int x,y;
    millWindow=window;
    for(x=0;x<4;x++)
      for(y=0;y<4;y++) {
	orientation[x+y*4]=0;
	if(x==y)
	  orientation[x+y*4]=1;
      }
  };
  ~Mill() {
    int i;
    delete field;
    for(i=0;i<MAX_STATES;i++) {
      if(state[i]) delete state[i];
    }
  }
  void init();
  void idle();
  void specialInput( int k, int x, int y );
  int mouseFunc(int button,int state,int x,int y);
  void motionFunc(int x,int y);
  void draw();
  int doMove(FieldPos *pos);
  void undoMove();
  void redoMove();
  bool mustRedisplay() {return redisplay;}
  
  bool isAiEnabled();
  int getAiColor();
  int getActivePlayerColor();
  bool isGameOver();
  int getWinner();
  void checkAndRunAi();
private:
  bool redisplay;
  //  IdMatrix orientation;
  float orientation[16];

  Field *field;
  State *state[MAX_STATES];
  int stateInd;
  MillWindow *millWindow;
};

#endif



