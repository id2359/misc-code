# 3D Mill Game Code Explanation

This document explains the architecture of the 3D Mill game, separating the original game mechanics (non-AI) and the newly added Artificial Intelligence (AI) playing opponent.

---

## 1. Core Game Architecture (Non-AI)

The original codebase is written in C++ using Qt5 and OpenGL. It follows a model-view-controller like pattern:

### A. Board Representation: [Field.h](file:///home/frug/Downloads/mill3d-1.1/Field.h) & [Field.cc](file:///home/frug/Downloads/mill3d-1.1/Field.cc)
- **`FieldPos` (Struct)**: Represents a single node on the board.
  - `status`: The color of the stone currently occupying this position (`1` for Yellow, `2` for White, `0` for empty, `-1` for invalid/non-playable space).
  - `mill[4][3]`: Defines the four potential mills (rows/lines of 3 nodes) that pass through this position.
  - `a1, b1, c1, d1`: Coordinate representations inside the concentric cubes.
- **`Field` (Class)**: Represents the entire board structure.
  - Initializes 3 concentric cubes (each with 20 playable positions, totaling 60 positions).
  - Handles the OpenGL logic to draw the board grid and render the placed stones (`ball` list).
  - [Field::getPos](file:///home/frug/Downloads/mill3d-1.1/Field.cc#L304) projects screen mouse coordinates `(x, y)` back into 3D coordinates using `gluProject` to find the nearest valid board position.

### B. State Machine & Rules: [State.h](file:///home/frug/Downloads/mill3d-1.1/State.h) & [State.cc](file:///home/frug/Downloads/mill3d-1.1/State.cc)
- **`State` (Class)**: Models a specific point in game history.
  - `color`: Active color in the transition.
  - `action`: State of the active player's turn (`SET`, `REMOVE`, `MOVE_REMOVE`, `MOVE_SET`, `JUMP_REMOVE`, `JUMP_SET`).
  - `stones[3]`: Array tracking `toSet` (number of stones remaining to place) and `left` (total active stones on the board or in reserve) for each player.
  - [State::setMove](file:///home/frug/Downloads/mill3d-1.1/State.cc#L6): Validates a move, modifies the board state via `doMove()`, copies itself, advances to the next player/action via `nextMove()`, and returns the next `State` object.

### C. Game Loop & UI: [Mill.h](file:///home/frug/Downloads/mill3d-1.1/Mill.h), [MillWindow.cc](file:///home/frug/Downloads/mill3d-1.1/MillWindow.cc) & [MillGLWidget.cc](file:///home/frug/Downloads/mill3d-1.1/MillGLWidget.cc)
- **`Mill` (Class)**: Tracks the stack of `State` objects up to `MAX_STATES` for undo/redo capability.
- **`MillWindow` (Class)**: Inherits from `QMainWindow`. Setup menus, status bar, and actions.
- **`MillGLWidget` (Class)**: Subclass of `QGLWidget`. Delegates right-clicks to the board coordinate mapper and calls `Mill::doMove`.

---

## 2. Added AI Components

The AI playing opponent is integrated seamlessly using the existing rules validation inside `State`.

### A. AI Move Search (Minimax with Alpha-Beta Pruning)
In [Mill.cc](file:///home/frug/Downloads/mill3d-1.1/Mill.cc#L688), we implemented the standard Alpha-Beta Minimax search:
- **Depth**: Currently searches 2 moves deep (1 full turn for the AI, 1 full turn for the opponent player).
- **Move Generation**: [getLegalMoves](file:///home/frug/Downloads/mill3d-1.1/Mill.cc#L430) simulates possible sequences of clicks corresponding to a turn. It backups the board status and rolls back any changes dynamically, ensuring the live game board state remains untouched during simulation.
  - For `SET` actions: Place stone (1 click) $\to$ If mill forms, remove opponent stone (2 clicks).
  - For `MOVE` / `JUMP` actions: Remove stone (1 click) $\to$ Place stone (2 clicks) $\to$ If mill forms, remove opponent stone (3 clicks).

### B. Heuristic Evaluation Function
[evaluateState](file:///home/frug/Downloads/mill3d-1.1/Mill.cc#L644) evaluates the favorability of any game state:
1. **Material Weight (1000 pts)**: Prioritizes retaining our own stones and capturing opponent's stones.
2. **Completed Mills (200 pts)**: Rewards forming 3-aligned rows.
3. **Blocked Stones (50 pts)**: Penalizes our own stones if they cannot move to any empty adjacent coordinates, while rewarding blocking the opponent.
4. **Threats / Two-Stone Configurations (80 pts)**: Looks for rows where 2 stones are aligned with 1 empty space, ready to complete a mill on the next turn.

### C. UI & Controller Integration
- **Checkable Option**: Added a menu option `"AI Opponent"` to the `"Controls"` menu in `MillWindow`.
- **Game Loops**: Updated [MillGLWidget::mousePressEvent](file:///home/frug/Downloads/mill3d-1.1/MillGLWidget.cc#L44) to trigger [Mill::checkAndRunAi](file:///home/frug/Downloads/mill3d-1.1/Mill.cc#L803) right after a human finishes their turn.
- **Undo / Redo Sync**: Modified [MillWindow::undoGame](file:///home/frug/Downloads/mill3d-1.1/MillWindow.cc#L115) and [MillWindow::redoGame](file:///home/frug/Downloads/mill3d-1.1/MillWindow.cc#L125) to undo/redo twice (AI move + human move) when the AI is active, preserving turn alignment.
- **Rules Correctness**: Fixed bugs in the game's winner-loser logic and updated the capture validation in `State::setMove` to correctly allow taking stones from a mill if the opponent has only mills.

### D. AI Engine Console Dock Widget
We added a styled `QDockWidget` side panel to display the AI's internal search process:
- **Status Indicator**: Changes to "Thinking..." in yellow/gold during the minimax search, and returns to "Idle" in green when done.
- **Search Depth**: Displays the current ply limit (2 plies).
- **Nodes Checked**: Updates dynamically with the exact number of states evaluated during search.
- **Score / Eval**: Displays a chess-like normalized evaluation (e.g. `+1.25` for AI advantage, `-0.50` for player advantage).
- **Think Time**: Shows the duration of the search in milliseconds.
- **Best Move Selected**: Translates the AI's chosen `FieldPos` click actions into a readable description (e.g. `Move Cube 1 (0,1,0) -> Cube 1 (0,2,0) & Cap Cube 0 (2,1,0)`).
- **Responsive Layout**: Resized the main window to `820px` width so the console fits nicely next to the 3D board canvas.

