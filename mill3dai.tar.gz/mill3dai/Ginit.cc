#include <iostream>
#include <cassert>
#include <GL/gl.h>
#include <GL/glu.h>

#include "Ginit.h"

extern unsigned long int woodTexture[65536/8];

GInit *GInit::instance;
int GInit::width;
int GInit::height;
int GInit::fullscreen=1;

GInit::GInit(int argc,char **argv,int width_,int height_) {
  instance=this;
  width=width_;
  height=height_;
  /*
  glutInitWindowPosition(0,0);
  glutInitWindowSize(width,height);
  glutInit(&argc,argv);
  glutInitDisplayMode( GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGB );
  assert(glutCreateWindow("") > 0 );
  glutReshapeFunc( reshapeCB );
  glutKeyboardFunc( keyInputCB );
  glutSpecialFunc( specialInputCB );
  glutIdleFunc( idleCB );
  glutDisplayFunc( initCB );
  glutMouseFunc( mouseFuncCB );
  glutPassiveMotionFunc( passiveMotionFuncCB );
  glutMotionFunc( motionFuncCB );
  */
}

void GInit::start() {
//  glutMainLoop();
}

void GInit::drawCB() {
  instance->draw();
}

void GInit::initCB() {
  instance->init();
//  glutDisplayFunc( drawCB );
}

void GInit::keyInputCB( unsigned char k, int x, int y ) {
  switch (k) {
  case 27:
      exit(0);
      break;
  }
  instance->input(k,x,y);
}

void GInit::specialInputCB( int k, int x, int y ) {
/*  switch (k) {
  case GLUT_KEY_PAGE_UP:
    fullscreen=(!fullscreen);
    XMesaSetFXmode(fullscreen ? XMESA_FX_FULLSCREEN : XMESA_FX_WINDOW);
  }
  instance->specialInput(k,x,y);*/
}

void GInit::mouseFuncCB(int button,int state,int x,int y) {
  instance->mouseFunc(button,state,x,y);
}

void GInit::passiveMotionFuncCB(int x,int y) {
  instance->passiveMotionFunc(x,y);
}

void GInit::motionFuncCB(int x,int y) {
  instance->motionFunc(x,y);
}

void GInit::reshapeCB(int width_,int height_) {
  glViewport(0, 0, width=(GLint)width_, height=(GLint)height_);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(70.0,width/(float)height,1,130.0); 
  glMatrixMode(GL_MODELVIEW);
}

void GInit::idleCB() {
  instance->idle();
} 

GLuint GInit::loadTexture(char *filename) {
  GLuint textureID=0;
  glGenTextures(1,&textureID);
  glBindTexture(GL_TEXTURE_2D,textureID);
/*  TIFF *tif;
  char emsg[1024];
  uint32 *texture;
  TIFFRGBAImage img;

  glGenTextures(1,&textureID);
  glBindTexture(GL_TEXTURE_2D,textureID);
  tif = TIFFOpen(filename, "r");
  if (tif == NULL) {
    fprintf(stderr, "Problem showing %s\n", filename);
    exit(1);
  }
  if (TIFFRGBAImageBegin(&img, tif, 0, emsg)) {
    texture = (uint32 *) _TIFFmalloc((tsize_t) (img.width * 
						img.height) * 
				     (tsize_t) sizeof(uint32));
    if (texture != NULL) {
      if (TIFFRGBAImageGet(&img, texture, img.width, img.height) == 0) {
        TIFFError(filename, emsg);
        exit(1);
      }
    }
    TIFFRGBAImageEnd(&img);
  } else {
    TIFFError(filename, emsg);
    exit(1);
  }*/
  gluBuild2DMipmaps(GL_TEXTURE_2D, 4, 256, 256/8,
		    GL_RGBA,
		    GL_UNSIGNED_BYTE,
		    woodTexture);
  return textureID;
//	return 0;
}

