#ifndef MILLGLWIDGET_H
#define MILLGLWIDGET_H

#include <qgl.h>

class QMouseEvent;
class Mill;
class MillWindow;

class MillGLWidget:public QGLWidget {
public:
  MillGLWidget(QWidget *w,Mill *m,QGLFormat &f);
  void initializeGL();
  void resizeGL( int w, int h );
  void paintGL();
  void mouseMoveEvent(QMouseEvent *e);
  void mousePressEvent(QMouseEvent *e);
  void mouseReleaseEvent(QMouseEvent *e);
  void setMill(Mill *m);
 private:
  Mill *mill;
  MillWindow *millWindow;
};

#endif
