/****************************************************************************
** MillWindow meta object code from reading C++ file 'MillWindow.h'
**
** Created: Fri Jan 21 14:17:58 2000
**      by: The Qt Meta Object Compiler ($Revision: 2.25.2.12 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "MillWindow.h"
#include <qmetaobject.h>


const char *MillWindow::className() const
{
    return "MillWindow";
}

QMetaObject *MillWindow::metaObj = 0;


#if QT_VERSION >= 200
static QMetaObjectInit init_MillWindow(&MillWindow::staticMetaObject);

#endif

void MillWindow::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QMainWindow::className(), "QMainWindow") != 0 )
	badSuperclassWarning("MillWindow","QMainWindow");

#if QT_VERSION >= 200
    staticMetaObject();
}

void MillWindow::staticMetaObject()
{
    if ( metaObj )
	return;
    QMainWindow::staticMetaObject();
#else

    QMainWindow::initMetaObject();
#endif

    typedef void(MillWindow::*m1_t0)();
    typedef void(MillWindow::*m1_t1)();
    typedef void(MillWindow::*m1_t2)();
    typedef void(MillWindow::*m1_t3)();
    typedef void(MillWindow::*m1_t4)();
    typedef void(MillWindow::*m1_t5)();
    typedef void(MillWindow::*m1_t6)();
    typedef void(MillWindow::*m1_t7)();
    typedef void(MillWindow::*m1_t8)();
    typedef void(MillWindow::*m1_t9)();
    typedef void(MillWindow::*m1_t10)();
    typedef void(MillWindow::*m1_t11)();
    typedef void(MillWindow::*m1_t12)(char*);
    typedef void(MillWindow::*m1_t13)();
    m1_t0 v1_0 = &MillWindow::newGame;
    m1_t1 v1_1 = &MillWindow::undoGame;
    m1_t2 v1_2 = &MillWindow::redoGame;
    m1_t3 v1_3 = &MillWindow::exitGame;
    m1_t4 v1_4 = &MillWindow::help;
    m1_t5 v1_5 = &MillWindow::about;
    m1_t6 v1_6 = &MillWindow::glversion;
    m1_t7 v1_7 = &MillWindow::toggleStatusBar;
    m1_t8 v1_8 = &MillWindow::toggleToolBar;
    m1_t9 v1_9 = &MillWindow::toggleSolid;
    m1_t10 v1_10 = &MillWindow::toggleTexture;
    m1_t11 v1_11 = &MillWindow::toggleFog;
    m1_t12 v1_12 = &MillWindow::setStatus;
    m1_t13 v1_13 = &MillWindow::showBeep;
    QMetaData *slot_tbl = new QMetaData[14];
    slot_tbl[0].name = "newGame()";
    slot_tbl[1].name = "undoGame()";
    slot_tbl[2].name = "redoGame()";
    slot_tbl[3].name = "exitGame()";
    slot_tbl[4].name = "help()";
    slot_tbl[5].name = "about()";
    slot_tbl[6].name = "glversion()";
    slot_tbl[7].name = "toggleStatusBar()";
    slot_tbl[8].name = "toggleToolBar()";
    slot_tbl[9].name = "toggleSolid()";
    slot_tbl[10].name = "toggleTexture()";
    slot_tbl[11].name = "toggleFog()";
    slot_tbl[12].name = "setStatus(char*)";
    slot_tbl[13].name = "showBeep()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    slot_tbl[6].ptr = *((QMember*)&v1_6);
    slot_tbl[7].ptr = *((QMember*)&v1_7);
    slot_tbl[8].ptr = *((QMember*)&v1_8);
    slot_tbl[9].ptr = *((QMember*)&v1_9);
    slot_tbl[10].ptr = *((QMember*)&v1_10);
    slot_tbl[11].ptr = *((QMember*)&v1_11);
    slot_tbl[12].ptr = *((QMember*)&v1_12);
    slot_tbl[13].ptr = *((QMember*)&v1_13);
    metaObj = new QMetaObject( "MillWindow", "QMainWindow",
	slot_tbl, 14,
	0, 0 );
}
