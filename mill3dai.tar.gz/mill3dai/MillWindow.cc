#include <iostream>
#include <cstring>
#include <cstdio>
#include <QPixmap>
#include <QToolBar>
#include <QToolButton>
#include <QMenu>
#include <QMenuBar>
#include <QFile>
#include <QFileDialog>
#include <QStatusBar>
#include <QMessageBox>
#include <QApplication>
#include <QAction>
#include <QGLWidget>
#include <QGLFormat>
#include <GL/gl.h>
#include <QDockWidget>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QFrame>
#include <QLabel>


#include "MillWindow.h"
#include "Mill.h"
#include "newIcon.xpm"
#include "undoIcon.xpm"
#include "redoIcon.xpm"
#include "millIcon.xpm"
#include "rules.h"

MillWindow::MillWindow()
    : QMainWindow( nullptr )
{
    QPixmap newI, undoI, redoI;

    newI = QPixmap( (const char**)newIcon );
    undoI = QPixmap( (const char**)undoIcon );
    redoI = QPixmap( (const char**)redoIcon );

    gameTools = new QToolBar( "Game", this );
    addToolBar(gameTools);

    gameTools->addAction(QIcon(newI), "New", this, SLOT(newGame()));
    gameTools->addAction(QIcon(undoI), "Undo", this, SLOT(undoGame()));
    gameTools->addAction(QIcon(redoI), "Redo", this, SLOT(redoGame()));

    gameMenu = new QMenu( "&Game", this );
    menuBar()->addMenu( gameMenu );
    gameMenu->addAction(QIcon(newI), "New", this, SLOT(newGame()), QKeySequence(Qt::CTRL + Qt::Key_N) );
    gameMenu->addSeparator();
    gameMenu->addAction(QIcon(undoI), "Undo", this, SLOT(undoGame()), QKeySequence(Qt::CTRL + Qt::Key_U) );
    gameMenu->addAction(QIcon(redoI), "Redo", this, SLOT(redoGame()), QKeySequence(Qt::CTRL + Qt::Key_R) );
    gameMenu->addSeparator();
    gameMenu->addAction("Exit", this, SLOT(exitGame()), QKeySequence(Qt::CTRL + Qt::Key_P) );

    aiEnabled = true;
    aiColor = 2;

    controlMenu = new QMenu( "&Controls", this );
    menuBar()->addMenu( controlMenu );
    tbAction = controlMenu->addAction( "Tool bar", this, SLOT(toggleToolBar()), QKeySequence(Qt::CTRL + Qt::Key_T) );
    tbAction->setCheckable( true );
    tbAction->setChecked( true );
    sbAction = controlMenu->addAction( "Status bar", this, SLOT(toggleStatusBar()), QKeySequence(Qt::CTRL + Qt::Key_B) );
    sbAction->setCheckable( true );
    sbAction->setChecked( true );
    aiAction = controlMenu->addAction( "AI Opponent", this, SLOT(toggleAi()) );
    aiAction->setCheckable( true );
    aiAction->setChecked( true );

    viewMenu = new QMenu( "&View", this );
    menuBar()->addMenu( viewMenu );
    solidAction = viewMenu->addAction( "Solid", this, SLOT(toggleSolid()) );
    solidAction->setCheckable( true );
    solidAction->setChecked( true );
    textureAction = viewMenu->addAction( "Texture", this, SLOT(toggleTexture()) );
    textureAction->setCheckable( true );
    textureAction->setChecked( true );
    fogAction = viewMenu->addAction( "Fog", this, SLOT(toggleFog()) );
    fogAction->setCheckable( true );
    fogAction->setChecked( true );
        
    helpMenu = new QMenu( "&Help", this );
    menuBar()->addMenu( helpMenu );
    helpMenu->addAction("Help", this, SLOT(help()), QKeySequence(Qt::CTRL + Qt::Key_H) );
    helpMenu->addAction("About", this, SLOT(about()) );
    helpMenu->addAction("GL Version", this, SLOT(glversion()) );

    mill=new Mill(this);
    QGLFormat *glformat=new QGLFormat();
    glformat->setDoubleBuffer(true);
    glformat->setRgba(true);
    glWidget=new MillGLWidget(this,mill,*glformat);
    setCentralWidget( glWidget );

    // ==========================================
    // AI Engine Console Dock Widget
    // ==========================================
    QDockWidget *dock = new QDockWidget("AI Engine Console", this);
    dock->setObjectName("aiDock");
    dock->setAllowedAreas(Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
    
    QWidget *dockContent = new QWidget();
    dockContent->setObjectName("aiDockContent");
    
    QVBoxLayout *layout = new QVBoxLayout(dockContent);
    layout->setContentsMargins(15, 15, 15, 15);
    layout->setSpacing(10);
    
    QLabel *statusHeader = new QLabel("AI ENGINE STATUS");
    statusHeader->setStyleSheet("font-size: 11px; font-weight: bold; color: #007acc; letter-spacing: 1px;");
    layout->addWidget(statusHeader);
    
    aiStatusLabel = new QLabel("Idle");
    aiStatusLabel->setStyleSheet("font-size: 20px; font-weight: bold; color: #2ecc71; padding: 5px 0px;");
    layout->addWidget(aiStatusLabel);
    
    QFrame *line = new QFrame();
    line->setFrameShape(QFrame::HLine);
    line->setStyleSheet("background-color: #2d2d30; max-height: 1px; border: none;");
    layout->addWidget(line);
    
    QGridLayout *grid = new QGridLayout();
    grid->setSpacing(8);
    
    QLabel *depthLabelText = new QLabel("Search Depth:");
    depthLabelText->setStyleSheet("color: #888888; font-weight: bold;");
    aiDepthLabel = new QLabel("2 plies");
    aiDepthLabel->setStyleSheet("color: #ffffff;");
    grid->addWidget(depthLabelText, 0, 0);
    grid->addWidget(aiDepthLabel, 0, 1);
    
    QLabel *nodesLabelText = new QLabel("Nodes Checked:");
    nodesLabelText->setStyleSheet("color: #888888; font-weight: bold;");
    aiNodesLabel = new QLabel("0");
    aiNodesLabel->setStyleSheet("color: #ffffff;");
    grid->addWidget(nodesLabelText, 1, 0);
    grid->addWidget(aiNodesLabel, 1, 1);
    
    QLabel *scoreLabelText = new QLabel("Score / Eval:");
    scoreLabelText->setStyleSheet("color: #888888; font-weight: bold;");
    aiScoreLabel = new QLabel("0.00");
    aiScoreLabel->setStyleSheet("color: #ffffff;");
    grid->addWidget(scoreLabelText, 2, 0);
    grid->addWidget(aiScoreLabel, 2, 1);
    
    QLabel *timeLabelText = new QLabel("Think Time:");
    timeLabelText->setStyleSheet("color: #888888; font-weight: bold;");
    aiTimeLabel = new QLabel("0 ms");
    aiTimeLabel->setStyleSheet("color: #ffffff;");
    grid->addWidget(timeLabelText, 3, 0);
    grid->addWidget(aiTimeLabel, 3, 1);
    
    layout->addLayout(grid);
    
    QFrame *line2 = new QFrame();
    line2->setFrameShape(QFrame::HLine);
    line2->setStyleSheet("background-color: #2d2d30; max-height: 1px; border: none;");
    layout->addWidget(line2);
    
    QLabel *bestMoveHeaderText = new QLabel("BEST MOVE SELECTED");
    bestMoveHeaderText->setStyleSheet("font-size: 11px; font-weight: bold; color: #e67e22; letter-spacing: 1px;");
    layout->addWidget(bestMoveHeaderText);
    
    aiBestMoveLabel = new QLabel("N/A");
    aiBestMoveLabel->setWordWrap(true);
    aiBestMoveLabel->setStyleSheet("font-size: 13px; color: #ecf0f1; background-color: #2c3e50; padding: 8px; border-radius: 4px; border: 1px solid #34495e;");
    layout->addWidget(aiBestMoveLabel);
    
    layout->addStretch();
    
    dockContent->setStyleSheet("background-color: #1c1c1f; font-family: 'Segoe UI', Arial, sans-serif;");
    dock->setWidget(dockContent);
    addDockWidget(Qt::RightDockWidgetArea, dock);
    
    dock->setStyleSheet(
        "QDockWidget::title {"
        "  background-color: #2c2c2f;"
        "  color: #a0a0a0;"
        "  padding: 6px;"
        "  font-weight: bold;"
        "}"
    );

    statusBar()->showMessage( "Ready", 2000 );
    setWindowTitle("GLMill");
    resize(820,500);
}

MillWindow::~MillWindow() {
}

void MillWindow::newGame() {
  if(mill)
    delete mill;
  mill=new Mill(this);
  ((MillGLWidget*)glWidget)->setMill(mill);
  mill->init();
  mill->reshapeCB(glWidget->width(),glWidget->height());
  mill->draw();
  glWidget->swapBuffers();

  if (aiEnabled) {
    mill->checkAndRunAi();
    if(mill->mustRedisplay()) {
      mill->draw();
      glWidget->swapBuffers();
    }
  }
}

void MillWindow::undoGame() {
  mill->undoMove();
  if (aiEnabled && mill->getActivePlayerColor() == aiColor) {
    mill->undoMove();
  }
  if(mill->mustRedisplay()) {
    mill->draw();
    glWidget->swapBuffers();
  }
}

void MillWindow::redoGame() {
  mill->redoMove();
  if (aiEnabled && mill->getActivePlayerColor() == aiColor) {
    mill->redoMove();
  }
  if(mill->mustRedisplay()) {
    mill->draw();
    glWidget->swapBuffers();
  }
}

void MillWindow::exitGame() {
    close();
}

void MillWindow::help() {
  QMessageBox::information(this, "Help", helpText);
}

void MillWindow::about() {
  char *aboutText=
    "I'm proud to present the version 1.1 of 3D mill to you\n"
    "3D mill is under the Gnu Public License\n"
    "Marcus Roth september 1999\n"
    "brede.roth@t-online.de"
    ;
  QPixmap millI = QPixmap( (const char**)millIcon );

  QMessageBox msgBox(this);
  msgBox.setWindowTitle("About 3D mill");
  msgBox.setText(aboutText);
  msgBox.setIconPixmap(millI);
  msgBox.exec();
}

void MillWindow::glversion() {
  glWidget->makeCurrent();
  const char *version = (const char*)glGetString(GL_VERSION);
  const char *extensions = (const char*)glGetString(GL_EXTENSIONS);
  const char *renderer = (const char*)glGetString(GL_RENDERER);

  if (!version) version = "Unknown";
  if (!extensions) extensions = "";
  if (!renderer) renderer = "Unknown";

  char *text=new char[
          strlen(version)+
          strlen(extensions)+
          strlen(renderer)+200];
  int i,len=0;
  
  sprintf(text,"OpenGL Version %s\n",version);
  sprintf(text,"%sOpenGL Extensions %s\n",text,extensions);
  sprintf(text,"%sOpenGL Renderer %s\n",text,renderer);
  for(i=0;i<(int)strlen(text);i++) {
    len++;
    if(text[i]=='\n') len=0;
    if(text[i]==' ' && len>60) {
        text[i]='\n';
        len=0;   
    }
  }
  
  QMessageBox::information(this, "OpenGL version", text);
  delete [] text;
}

void MillWindow::toggleToolBar()
{
  if ( gameTools->isVisible() ) {
	gameTools->hide();
	tbAction->setChecked( false );
  } else {
	gameTools->show();
	tbAction->setChecked( true );
  }
}

void MillWindow::toggleStatusBar()
{
  if ( statusBar()->isVisible() ) {
	statusBar()->hide();
	sbAction->setChecked( false );
  } else {
	statusBar()->show();
	sbAction->setChecked( true );
  }
}

void MillWindow::toggleSolid()
{
  if( !solidAction->isChecked() ) {
    glPolygonMode(GL_FRONT,GL_LINE);
  } else {
    glPolygonMode(GL_FRONT,GL_FILL);
  }
  mill->draw();
  glWidget->swapBuffers();
}

void MillWindow::toggleTexture()
{
  if( !textureAction->isChecked() ) {
    glDisable(GL_TEXTURE_2D);
  } else {
    glEnable(GL_TEXTURE_2D);
  }
  mill->draw();
  glWidget->swapBuffers();
}

void MillWindow::toggleFog()
{
  if( !fogAction->isChecked() ) {
    glDisable(GL_FOG);
  } else {
    glEnable(GL_FOG);
  }
  mill->draw();
  glWidget->swapBuffers();
}

void MillWindow::setStatus(char *msg) {
  static char oldmsg[100]={0};
  if(strcmp(oldmsg,msg)!=0) {
    statusBar()->showMessage( msg );
    strcpy(oldmsg,msg);
  }
}

void MillWindow::showBeep() {
}

void MillWindow::toggleAi() {
  aiEnabled = aiAction->isChecked();
  if (aiEnabled && mill) {
    mill->checkAndRunAi();
    if (mill->mustRedisplay()) {
      mill->draw();
      glWidget->swapBuffers();
    }
  }
}

void MillWindow::updateAiConsole(const QString &status, int nodes, int score, const QString &bestMove, int timeMs) {
  aiStatusLabel->setText(status);
  if (status == "Thinking...") {
    aiStatusLabel->setStyleSheet("font-size: 20px; font-weight: bold; color: #f1c40f; padding: 5px 0px;");
  } else {
    aiStatusLabel->setStyleSheet("font-size: 20px; font-weight: bold; color: #2ecc71; padding: 5px 0px;");
  }
  
  aiNodesLabel->setText(QString::number(nodes));
  
  if (score > 500000) {
    aiScoreLabel->setText("Mate (AI Win)");
  } else if (score < -500000) {
    aiScoreLabel->setText("Mate (Player Win)");
  } else {
    double scoreVal = score / 1000.0;
    aiScoreLabel->setText(QString("%1%2").arg(scoreVal >= 0 ? "+" : "").arg(scoreVal, 0, 'f', 2));
  }
  
  aiBestMoveLabel->setText(bestMove);
  aiTimeLabel->setText(QString("%1 ms").arg(timeMs));
}

extern "C" {
extern void  glXCreateGLXPixmapMESA() {}
extern void  glXReleaseBuffersMESA() {}
}
